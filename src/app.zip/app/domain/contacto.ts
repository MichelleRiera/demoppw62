export class Contacto {
    nombre: string = '';
    cedula: string = '';
    direccion: string = '';
}